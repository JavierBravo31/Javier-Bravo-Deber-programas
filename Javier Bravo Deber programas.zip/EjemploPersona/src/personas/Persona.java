
package personas;

public class Persona {
    public String nombre;
    public String apellido;
    public int edad;
    public int ci;

    public Persona() {
    }

    public Persona(String nombre, String apellido, int edad, int ci) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.ci = ci;
    }

    public int getCi() {
        return ci;
    }
    public void setCi(int ci){
        this.ci=ci;
    }
}
