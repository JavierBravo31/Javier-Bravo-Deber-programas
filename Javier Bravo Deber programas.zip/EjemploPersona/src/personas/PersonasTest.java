/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personas;

/**
 *
 * @author Usuario
 */
public class PersonasTest {
 public static void main(String[] args) {
        Persona cod=new Persona("Javier","Bravo",19,1725085177);
        cod.setCi(1725085177);
        
        System.out.println(" nombre : " + cod.nombre + " apellido :" + cod.apellido + "  edad : " + cod.edad + " Mi cedula de identidad es : " + cod.getCi());
  
    }
} 
