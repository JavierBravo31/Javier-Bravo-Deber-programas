
package vehiculos;

public abstract class VehiculosTest {
    public static void main(String[] args) {
        Moto moto = new Moto("Yamaha", 0, false, "Deportiva", 0);
        moto.marca = "Honda";
        moto.puertas = 0;
        moto.enMarcha = true;
        System.out.println("Marca de la moto: " + moto.marca);
        System.out.println("Tipo de moto: " + moto.tipoMoto);
        System.out.println("Número de puertas de la moto: " + moto.puertas);
        System.out.println("Estado de marcha de la moto: " + moto.enMarcha);
        moto.arrancar();
        Carro carro = new Carro("Toyota", 4, false, 5, 0);
        carro.marca = "Ford";
        carro.enMarcha = true;
        System.out.println("Marca del carro: " + carro.marca);
        System.out.println("Capacidad de pasajeros del carro: " + carro.capacidadPasajeros);
        System.out.println("Estado de marcha del carro: " + carro.enMarcha);

        carro.arrancar();
    }
}