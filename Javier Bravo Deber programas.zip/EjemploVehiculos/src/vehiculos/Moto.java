package vehiculos;

public class Moto extends Vehiculos {
    public String tipoMoto;

    public Moto(String marca, int puertas, boolean enMarcha, String tipoMoto, int ventana) {
        super(marca, puertas, enMarcha, ventana);
        this.tipoMoto = tipoMoto;
    }

    @Override
    public void arrancar() {
        System.out.println("Arrancando la moto...");
    }
}