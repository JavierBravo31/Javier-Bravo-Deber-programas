package vehiculos;

public class Carro extends Vehiculos {
    public int capacidadPasajeros;

    public Carro(String marca, int puertas, boolean enMarcha, int capacidadPasajeros, int ventana) {
        super(marca, puertas, enMarcha, ventana);
        this.capacidadPasajeros = capacidadPasajeros;
    }

    @Override
    public void arrancar() {
        System.out.println("Arrancando el carro...");
    }
}