package vehiculos;

public abstract class Vehiculos {
    public String marca;
    public int puertas;
    public boolean enMarcha;
    private int ventana;

    public Vehiculos(String marca, int puertas, boolean enMarcha, int ventana) {
        this.marca = marca;
        this.puertas = puertas;
        this.enMarcha = enMarcha;
        this.ventana = ventana;
    }

    public int getVentana() {
        return ventana;
    }

    public void setVentana(int ventana) {
        this.ventana = ventana;
    }

    public abstract void arrancar();
}